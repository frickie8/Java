/**
 * It has howToColor() method return void
 */

package thecolorableinterface;

public interface Colorable {
    /**
     * Describe Color all four sides
     */
    public abstract void howToColor();
}
